import { TitleFormatPipe } from './title-format.pipe';

describe('TitleFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new TitleFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
